from django.shortcuts import render, HttpResponse, redirect
import random
from time import gmtime, strftime

def index(request):

    if 'gold' not in request.session or 'activities' not in request.session:
        request.session['gold'] = 0
        request.session['activities'] = []
    contex = {
        "activities": request.session['activities']
    } 
    return render(request, 'index.html', contex)

def process_money(request):
    if request.method == 'POST':
        myGold = request.session['gold']
        activities = request.session['activities']
        location = request.POST['location']
        if location == 'FARM': 
            goldThisTurn = round(random.random()*10+10)
            print('from farm', goldThisTurn)

        elif location == 'CAVE': 
            goldThisTurn = round(random.random()*5+5)

        elif location == 'HOUSE': 
            goldThisTurn = round(random.random()*3+2)

        else:
            
            goldThisTurn = round(random.random()*100-50)



        myGold += goldThisTurn
        request.session['gold'] = myGold
        time= strftime("%Y-%m-%d %H:%M %p", gmtime())

        if goldThisTurn >= 0:
            str = f"Earned {goldThisTurn} from the {location} {time}"

        else:
            goldThisTurn = -goldThisTurn
            str = f"Lose {goldThisTurn} from the {location} {time}"

        activities.insert(0,str)
        request.session['activities'] = activities

# redirct to home page. if you want to redirect to somewhere else type urls there
    return redirect('/') 