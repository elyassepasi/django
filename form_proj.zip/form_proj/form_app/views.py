from django.shortcuts import render, redirect, HttpResponse

def index(request):
    return render(request,'form_in.html')

def result(request):
    if request.method== 'POST':
        info= {
            'location' : request.POST['city'],
            'prefered_language' : request.POST['language'],
            'your_name': request.POST['name']

        }
        return render(request, 'list_out.html',info)
    return render(request,'list_out.html')