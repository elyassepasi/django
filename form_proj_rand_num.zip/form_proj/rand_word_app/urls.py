from django.urls import path, include
from . import views

urlpatterns = [
    path('word/randgen', views.rand),
    path('wordreset', views.reset),
    
]