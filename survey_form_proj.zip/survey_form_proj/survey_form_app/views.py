from django.shortcuts import render, HttpResponse, redirect

def index(request):
    form_path = redirect('/form')
    return form_path
    # return HttpResponse('please add /form to get to your form')


def form(request):
    
    return render (request,'survey.html')

def display(request):
    if request.method == 'POST':
        context = {
            'name': request.POST['name'],
            'lang': request.POST['location'],
            'loc': request.POST['language']
        }
        return render(request, 'display.html', context)
    return render(request, 'display.html')