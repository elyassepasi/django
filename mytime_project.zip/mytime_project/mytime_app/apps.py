from django.apps import AppConfig


class MytimeAppConfig(AppConfig):
    name = 'mytime_app'
