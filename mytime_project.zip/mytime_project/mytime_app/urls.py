from django.urls import path
from . import views

urlpatterns = [
    path('currenttime/', views.index),
    path('greeting/', views.greeting)
]